package main

var m4 = map[string]int{
	"a": 1,
	"b": 2,
}

func main() {

}
