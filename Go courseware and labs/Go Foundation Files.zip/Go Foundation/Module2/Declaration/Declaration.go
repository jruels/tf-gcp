package main

func main() {

	var a int = 15

	var b int

	var c = 15

	var f, g int = 5, 6

	var (
		h = 10
		i = "test"
		j int
	)
}
