package main

func main() {

	a := 1

	b, c := 5, 6

	d, e, f := 1, true, 4.56

}
