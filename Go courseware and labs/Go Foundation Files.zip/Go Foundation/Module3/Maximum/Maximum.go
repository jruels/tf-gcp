package main

import (
	"fmt"
	"math"
)

func main() {
	fmt.Println("MaxFloat32\t", math.MaxFloat32)
	fmt.Println("MaxFloat64\t", math.MaxFloat64)
	fmt.Println("MaxInt16\t", math.MaxInt16)
	fmt.Println("MaxInt32\t", math.MaxInt32)
	fmt.Println("MaxInt8\t", math.MaxInt8)
	fmt.Println("MinInt16\t", math.MinInt16)
	fmt.Println("MinInt32\t", math.MinInt32)
	fmt.Println("MaxInt64\t", math.MaxInt64)
}
