package main

import "fmt"

func main() {

	b := []int{1, 2, 3, 4, 5}

	fmt.Print(b)

	if a := 5; a > 4 {
		fmt.Println(a)
	}

}
