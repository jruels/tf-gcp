# Ansible Error Handling

There are two choices available for this lab. One is step-by-step - copy/paste, and the other is an intermediate objective based scenario where you have to figure out the solution on your own.

Choose wisely :) 

[Ansible Error Handling - Introductory](error_handling_intro.md)   
[Ansible Error Handling - Intermediate](error_handling_intermediate.md)

